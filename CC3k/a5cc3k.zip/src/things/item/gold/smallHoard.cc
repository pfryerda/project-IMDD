#include "smallHoard.h"
using namespace std;

string SmallHoard::getName() { return "small hoard"; }
int SmallHoard::getAmount()  { return 2; }
