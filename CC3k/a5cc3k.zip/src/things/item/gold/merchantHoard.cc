#include "merchantHoard.h"
using namespace std;

string MerchantHoard::getName() { return "merchant hoard"; }
int MerchantHoard::getAmount()  { return 4; }
